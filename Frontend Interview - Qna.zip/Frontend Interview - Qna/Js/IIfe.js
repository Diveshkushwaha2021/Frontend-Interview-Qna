(function (message) {
	console.log("hello User !" + message)
})("Nice to see you");