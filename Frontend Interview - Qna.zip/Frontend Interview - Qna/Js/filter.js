const myarray = [1, 5, 2, 4, 6, 7, 17, 8, 11, 33, 36, 30, 52, 76,]

let compnies = [
	{ name: "Walmart", age: 32, email: "Walmart@gmail.com", category: "Service Based" },
	{ name: "flipkart", age: 12, email: "flipkart@gmail.com", category: "Product Based" },
	{ name: "amazone", age: 25, email: "amazone@gmail.com", category: "Product Based" },
	{ name: "cashfree", age: 8, email: "cashfree@gmail.com", category: "Service Based" },
	{ name: "", age: 18, email: "paytm@gmail.com", category: "Service Based" },

]

// let ages = myarray.filter((age) => {
// 	if (age > 10) {
// 		return true
// 	}
// })
// console.log(ages);

// let age_lismit = myarray.filter((age) => age >= 10)
// console.log(age_lismit);


let data = compnies.filter((company) => {
	if (company.category === "Product Based") {
		return true
	}
})
console.log(data)

let data1 = compnies.filter(company => company.category === "Product Based")
console.log(data1)

let data2 = compnies.filter(company => console.log(`${company.name}  ${company.email}`))
console.log(data2)