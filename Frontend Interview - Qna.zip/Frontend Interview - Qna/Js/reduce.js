const myarray = [1, 5, 2, 4, 6, 7, 17, 8, 11, 33, 36, 30, 52, 76,]

//sort 
const shorted = myarray.sort((a, b) => (a - b));
console.log(shorted)

//reduce method
const arraySum = myarray.reduce((total, age) => total + age, 0)
console.log(arraySum);