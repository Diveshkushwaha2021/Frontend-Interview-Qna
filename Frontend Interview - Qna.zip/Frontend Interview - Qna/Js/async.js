console.log("hello");
console.log("World");

async function getData() {
	let dataFromserver = await fetch("https://jsonplaceholder.typicode.com/posts")
	console.log(await dataFromserver.json());

}

getData()

console.log("At 3pm we have a team meeting with Piyush and other team members");
