let mutiply = function (x, y) {  //in argument x store =2 and y store = 5
	console.log(x * y);
}

// this is function currying 
let multiplytwo = mutiply.bind(this, 2);
multiplytwo(5)

let multiplythree = mutiply.bind(this, 10);
multiplythree(8)






// Currying is a functional programming technique where a function with multiple arguments is transformed into a series of functions, each taking a single argument.

// Instead of taking all arguments at once, the curried function takes the first argument, returns a new function that takes the next argument, and so on until all arguments are provided. The final function then returns the result.

// In simpler terms, currying breaks down a function that takes multiple parameters into a chain of functions that each take one parameter.


// Why is Currying useful in JavaScript?
// Currying offers several advantages, especially when working with functional programming patterns:

// It helps us to create a higher-order function
// It reduces the chances of error in our function by dividing it into multiple smaller functions that can handle one responsibility.
// It is very useful in building modular and reusable code
// It helps us to avoid passing the same variable multiple times
// It makes the code more readable




// function currying with Closure

//closure function
let mutiply_c = function (x) {
	return function (y) {
		console.log(x * y);
	}
}

// this is function currying 
let multiply_variables = mutiply_c(2);
multiply_variables(5)