let name = {
	fname: "Vibha",
	lname: "Pundir"
}
let printName = function (hometown, state, Country) {
	console.log("Hii," + this.fname + " " + this.lname + "lives in " + hometown + " " + state + " " + Country);
}

let myfunction = printName.bind(name, "Meerut");
myfunction("U.P", "India");

Function.prototype.self_bind = function (...args) {
	let obj = this
	params = args.slice(1);
	return function (...args2) {
		obj.apply(args[0], [...params, ...args2]);
		//obj.call(args[0]);
	}
}




let myfunction2 = printName.self_bind(name, "Jalander");
myfunction2("Punjab", "India");
