
//1. event Bubbling : events trigger from "bottom to Top"
// usecapture :default (false)

// document.querySelector("#grandparent").addEventListener('click', () => {
// 	console.log("Granparent Clicked");
// }, false)

// document.querySelector("#parent").addEventListener('click', () => {
// 	console.log("Parent Clicked");
// }, false)

// document.querySelector("#child").addEventListener('click', () => {
// 	console.log("Child Clicked ");
// }, false)



//2. event Capturing or Trickling : events trigger from "Top to Bottom"
// usecapture : true
// document.querySelector("#grandparent").addEventListener('click', () => {
// 	console.log("Granparent Clicked");
// }, true)

// document.querySelector("#parent").addEventListener('click', () => {
// 	console.log("Parent Clicked");
// }, true)

// document.querySelector("#child").addEventListener('click', () => {
// 	console.log("Child Clicked \n\n\n\n");
// }, true)


// stopPropagation():

// 1. stopPropagation() in Bubbling Events

// document.querySelector("#grandparent").addEventListener('click', () => {
// 	console.log("Granparent Clicked");
// }, false)

// document.querySelector("#parent").addEventListener('click', () => {
// 	console.log("Parent Clicked");
// }, false)

// document.querySelector("#child").addEventListener('click', (e) => {
// 	console.log("Child Clicked ");
// 	e.stopPropagation();
// }, false)


// 1. stopPropagation() in Capturing Events

document.querySelector("#grandparent").addEventListener('click', () => {
	console.log("Granparent Clicked");
}, true)

document.querySelector("#parent").addEventListener('click', (e) => {
	console.log("Parent Clicked");
	e.stopPropagation();
}, true)

document.querySelector("#child").addEventListener('click', (e) => {
	console.log("Child Clicked ");
}, true)