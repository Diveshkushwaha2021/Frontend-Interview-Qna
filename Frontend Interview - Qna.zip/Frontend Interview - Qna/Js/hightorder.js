function add(a, b, cb) {
	let result = a + b;
	cb(result);
}
// cb : callback
// why it is high order function : add is a high order fun. because of it take function as an "arguments"
add(10, 20, (vall) => console.log(vall));
add(10, 20, vall => console.log(vall));