// Debouncing in js

let counter = 0;
const getData = () => {
	console.log("fetching Data ..." + counter++);
}

// eventPlay = eventPlay is an debouncing method that takes 2 arguments
const eventPlay = function (fn, d) {
	let timer;
	return function () {
		let content = this;
		args = arguments;
		clearTimeout(timer)
		timer = setTimeout(() => {
			getData.apply(content, arguments);
		}, d);
	}

}






const betterResult = eventPlay(getData, 300)