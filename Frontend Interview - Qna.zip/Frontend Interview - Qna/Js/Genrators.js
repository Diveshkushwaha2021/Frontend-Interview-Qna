//What is Iterator Pattern?

//Generator function

// YIELD keyword