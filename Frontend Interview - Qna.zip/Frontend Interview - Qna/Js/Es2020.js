//1. optional chaning // 

let name = person?.addresh?.street?.name;

//2 Nullish Coalescing

let Fname = person?.name ?? 'Unknown';

//3. Bigint
const x = 12345678901234567890n;

//4. globalThis
console.log(globalThis === window);

//5 .matchAll()
const regex = /(\w)(\d)/g;
const str = 'a1b2c3';
for (const match of str.matchAll(regex)) {
	console.log(match)
}

//6. Promise.allSettled()

//7. String.prototype.at()

//8.Error Cause