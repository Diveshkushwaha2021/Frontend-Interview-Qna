const myarray = [1, 5, 2, 4, 6, 7, 17, 8, 11, 33, 36, 30, 52, 76,]

//foreach

// myarray.forEach((element) => {
// 	console.log(element)
// })

let array_list = myarray.forEach((e, index) => (console.log(e, index)))