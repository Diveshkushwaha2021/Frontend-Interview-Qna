// example 1 

// document.querySelector('#category').addEventListener('click', (e) => {
// 	let path = e.target.id;
// 	console.log(path);
// 	window.location.href = '/' + path;
// })


// example 2

document.querySelector('#form').addEventListener('keyup', (e) => {
	console.log(e)
	if (e.target.dataset.uppercase != undefined) {
		e.target.value = e.target.value.toUpperCase();
	}
})