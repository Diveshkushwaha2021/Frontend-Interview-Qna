const myarray = [1, 2, 3, 4, 5];

let obj = new Set(myarray)
obj.add(5);
obj.add(5);
obj.delete(5)

var obj1 = { name: "vinay" }
obj.add(obj1)
console.log(obj)
console.log(obj.has(20))

obj.forEach((element) => {
	console.log(element);
});


//map : key and value
let mymap = new Map([["k1", "read"], ["k2", "write"]])
mymap.set("k2", "update")
// mymap.delete("k2")
//console.log(mymap)
console.log(mymap.get('k2'))

mymap.forEach((key, value) => {
	console.log(`key:${key}, value:${value}`);
})


//weakset and WeakMap
// only store an object
// you cann't iterat
let ws = new WeakSet();
let object1 = { name: "vivak" }
let object2 = {}
ws.add(object1)
ws.add(object2)
console.log(ws)
ws.delete(object1);
console.log(ws.has(object1))


