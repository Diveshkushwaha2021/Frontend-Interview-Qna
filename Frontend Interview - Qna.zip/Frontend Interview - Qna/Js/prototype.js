// Everything in javascript is nothing but an Object.

// All JavaScript objects inherit properties and methods from a prototype.In the previous chapter we learned how to use an object constructor:
//https://www.w3schools.com/js/js_object_prototypes.asp


const arr = ["Ankit", "Sumit"];

let object = {
	name: "Amit",
	city: "Meerut",
	getIntro: function () {
		console.log(this.name + " from " + this.city);
	}
}
console.log(object.name);
console.log(object.name.charAt(3));
console.log(object.getIntro());

let object2 = {
	name: "Pawan"
}

object2.__proto__ = object;
console.log(object2.name);
console.log(object2.city);
console.log(object2.getIntro());

console.log(object2.addresh);







// object.prototype is a "object prototype"
// amit

// object.__proto__.__proto__ is "null"

// t

//for function
Function.prototype.mybind = function () {
	console.log("function prototype called")
}

function fun() {

}
console.log(fun.mybind());

// array.prototype is "Array prototype"
// array.prototype.prototype is a  "object prototype"
// array.prototype.prototype.prototype is a  "null"


//fun.prototype is a "function prototype"
//fun.prototype.prototype is "object prototype"



