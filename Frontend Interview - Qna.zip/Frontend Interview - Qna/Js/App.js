// Call , Apply and Bind

// let name = {
// 	firstName: "Divesh",
// 	LastName: "Kushwaha",
// 	FullName: function () { // fullName is a method
// 		console.log(this.firstName + " " + this.LastName);
// 	}
// }

// name.FullName();

// let name2 = {
// 	firstName: "Rishabh",
// 	LastName: "Khatana",

// }

// // function borrowing from other objects
// name.FullName.call(name2);



//2


let name = {
	firstName: "Divesh",
	LastName: "Kushwaha",
}

let FullName = function (State, role) {
	console.log("hii, I am " + this.firstName + " " + this.LastName + " from " + State + ". I am senior " + role);
}

FullName.call(name, "Noida Uttar Prsdesh", "Nodejs Developer");

let name2 = {
	firstName: "Rishabh",
	LastName: "Khatana",
}

FullName.call(name2, "Meerut Uttar Prsdesh", "java Developer");

//apply
FullName.apply(name2, ["Meerut Uttar Prsdesh", "java Developer"]);

//bind : provide a copy that is invoke later

