// Rest operator

function addtion(a, b, c, ...oth) {
	console.log(a + b + c)
}

let result = addtion(4, 9, 5, 11, 15, 7);
console.log(result)



// spread


const arrName = ["Vikalp", "Anuj", "Mohit", "Rishabh", "Jigyanshu"]

function names(name1, name2, name3) {
	console.log(name1, name2, name3)
}

names(...arrName);